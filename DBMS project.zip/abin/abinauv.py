import streamlit as st
import sqlite3
from datetime import datetime
import time

# Enhanced Database connection with retry and WAL mode
def get_db_connection():
    retries = 10  # Increased retry count for handling lock
    while retries > 0:
        try:
            conn = sqlite3.connect('railway.db', timeout=10)  # Set timeout to 10 seconds
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL;")  # Enable WAL mode
            conn.execute("PRAGMA busy_timeout = 3000;")  # Set busy timeout to 3 seconds
            return conn
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                time.sleep(0.5)  # Wait longer before retrying
                retries -= 1
            else:
                raise
    raise Exception("Failed to acquire database connection after several retries.")

# Function to fetch all trains
def get_all_trains():
    with get_db_connection() as conn:
        return conn.execute("SELECT * FROM train").fetchall()

# Function to fetch a specific train by ID
def get_train_by_id(train_id):
    with get_db_connection() as conn:
        return conn.execute("SELECT * FROM train WHERE id = ?", (train_id,)).fetchone()

# Function to book a ticket
def book_ticket(train_id, passenger_id, seat_number, booking_date):
    with get_db_connection() as conn:
        conn.execute(
            "INSERT INTO reservation (train_id, passenger_id, seat_number, booking_date) VALUES (?, ?, ?, ?)",
            (train_id, passenger_id, seat_number, booking_date)
        )
        conn.execute("UPDATE train SET available_seats = available_seats - 1 WHERE id = ?", (train_id,))
        conn.commit()

# Function to add a new passenger
def add_passenger(name, age, gender, contact_info):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO passenger (name, age, gender, contact_info) VALUES (?, ?, ?, ?)",
            (name, age, gender, contact_info)
        )
        return cursor.lastrowid

# Function to get reservations
def get_reservations():
    with get_db_connection() as conn:
        return conn.execute("SELECT * FROM reservation").fetchall()

# Function to get supervisor information
def get_supervisor_info():
    with get_db_connection() as conn:
        return conn.execute("SELECT * FROM supervisor").fetchone()

# Streamlit App
st.title("Railway Reservation System")

menu = ["Home", "Search Trains", "Book Ticket", "Cancel Ticket", "View Reservations", "Contact Supervisor"]
choice = st.sidebar.selectbox("Menu", menu)

if choice == "Home":
    st.subheader("Available Trains")
    trains = get_all_trains()
    for train in trains:
        st.write(f"Train Name: {train['name']}, From: {train['source']} to {train['destination']}")
        st.write(f"Departure: {train['departure_time']}, Arrival: {train['arrival_time']}")
        st.write(f"Total Seats: {train['total_seats']}, Available Seats: {train['available_seats']}")
        st.write("---")

elif choice == "Search Trains":
    st.subheader("Search for Trains")
    source = st.text_input("Source")
    destination = st.text_input("Destination")
    if st.button("Search"):
        with get_db_connection() as conn:
            query = "SELECT * FROM train WHERE source = ? AND destination = ?"
            results = conn.execute(query, (source, destination)).fetchall()
        if results:
            for train in results:
                st.write(f"Train: {train['name']} | Departure: {train['departure_time']} | Arrival: {train['arrival_time']} | Available Seats: {train['available_seats']}")
        else:
            st.write("No trains found for this route.")

elif choice == "Book Ticket":
    st.subheader("Book a Ticket")
    train_id = st.number_input("Train ID", min_value=1)
    passenger_name = st.text_input("Passenger Name")
    passenger_age = st.number_input("Passenger Age", min_value=1)
    passenger_gender = st.selectbox("Gender", ["Male", "Female", "Other"])
    contact_info = st.text_input("Contact Information")

    if st.button("Submit"):
        passenger_id = add_passenger(passenger_name, passenger_age, passenger_gender, contact_info)
        train = get_train_by_id(train_id)
        
        if train and train['available_seats'] > 0:
            seat_number = train['total_seats'] - train['available_seats'] + 1
            booking_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            book_ticket(train_id, passenger_id, seat_number, booking_date)
            st.success(f"Ticket booked successfully! Seat Number: {seat_number}")
        else:
            st.error("No seats available.")

elif choice == "Cancel Ticket":
    st.subheader("Cancel a Ticket")
    reservation_id = st.number_input("Reservation ID", min_value=1)
    if st.button("Cancel Reservation"):
        with get_db_connection() as conn:
            conn.execute("DELETE FROM reservation WHERE id = ?", (reservation_id,))
            conn.commit()
            st.success("Reservation cancelled successfully.")

elif choice == "View Reservations":
    st.subheader("All Reservations")
    reservations = get_reservations()
    for res in reservations:
        st.write(f"Reservation ID: {res['id']} | Train ID: {res['train_id']} | Passenger ID: {res['passenger_id']} | Seat Number: {res['seat_number']} | Booking Date: {res['booking_date']}")
        st.write("---")

elif choice == "Contact Supervisor":
    st.subheader("Technical Support")
    supervisor = get_supervisor_info()
    if supervisor:
        st.write(f"Supervisor: {supervisor['name']}")
        st.write(f"Phone: {supervisor['phone']}")
        st.write(f"Email: {supervisor['email']}")

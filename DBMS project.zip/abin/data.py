import sqlite3

def get_db_connection():
    conn = sqlite3.connect('railway.db')
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS train (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        source TEXT NOT NULL,
                        destination TEXT NOT NULL,
                        departure_time TEXT NOT NULL,
                        arrival_time TEXT NOT NULL,
                        total_seats INTEGER NOT NULL,
                        available_seats INTEGER NOT NULL
                    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS passenger (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        age INTEGER NOT NULL,
                        gender TEXT NOT NULL,
                        contact_info TEXT DEFAULT ''
                    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS reservation (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        train_id INTEGER NOT NULL,
                        passenger_id INTEGER NOT NULL,
                        seat_number INTEGER NOT NULL,
                        booking_date TEXT NOT NULL,
                        FOREIGN KEY(train_id) REFERENCES train(id),
                        FOREIGN KEY(passenger_id) REFERENCES passenger(id)
                    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS supervisor (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        phone TEXT NOT NULL,
                        email TEXT NOT NULL
                    )''')

    cursor.execute("INSERT OR IGNORE INTO supervisor (name, phone, email) VALUES ('John Doe', '+1234567890', 'support@railway.com')")
    cursor.execute('''INSERT OR IGNORE INTO train (name, source, destination, departure_time, arrival_time, total_seats, available_seats) 
                      VALUES 
                      ('Express 101', 'New York', 'Los Angeles', '2024-11-15 08:00', '2024-11-15 18:00', 300, 250),
                      ('Express 102', 'Chicago', 'San Francisco', '2024-11-16 10:00', '2024-11-16 20:00', 250, 220),
                      ('Express 103', 'Dallas', 'Miami', '2024-11-17 06:00', '2024-11-17 16:00', 350, 300)
                   ''')
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_tables()